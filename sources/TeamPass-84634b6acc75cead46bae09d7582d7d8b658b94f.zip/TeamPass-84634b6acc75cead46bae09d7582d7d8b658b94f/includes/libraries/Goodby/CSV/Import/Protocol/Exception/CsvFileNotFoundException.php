<?php

namespace Goodby\CSV\Import\Protocol\Exception;

/**
 * throw if csv file not found
 */
class CsvFileNotFoundException extends \RuntimeException
{
}
