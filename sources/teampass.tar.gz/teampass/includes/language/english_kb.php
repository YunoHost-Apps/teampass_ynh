<?php
$LANG['category'] = "Category";
$LANG['kb'] = "Knowledge Base";
$LANG['kb_anyone_can_modify'] = "Anyone can modify it";
$LANG['kb_form'] = "Manage entries in KB";
$LANG['new_kb'] = "Add a new KB";
